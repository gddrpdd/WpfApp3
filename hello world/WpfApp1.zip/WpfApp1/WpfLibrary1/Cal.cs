
namespace WpfLibrary1
{
    public class Cal
    {public static int Add(int x, int y)
        {
            return x + y;
        }
    }

}
